<?php

require "inc/shortcode/shortcode.php";
require "inc/wp_codex/post-type-expertise.php";
require "inc/wp_codex/media_upload.php";

add_theme_support( 'post-thumbnails', array( 'post' ) );  
add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
