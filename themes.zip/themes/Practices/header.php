<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  
<style>
.main_header {
  height: 80px;
  width: 100%;
  background-color: #2C3F50;
}

.main_header .main_header--wrap {
  width: 1440px;
  margin: auto;
  padding: 0px;
}

.main_header  .main_header--wrap {
  display: -ms-grid;
  display: grid;
  -ms-grid-columns: 1fr 1fr;
      grid-template-columns: 1fr 1fr;
}
.main_header .main_header--inner .main_header--nav-ctn ul {
  list-style: none;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
align-content: center;
}

.main_header .main_header--inner .main_header--nav-ctn ul li a {
  text-decoration: none;
  margin-right: 50px;
  color: white;
}
</style>
<?php wp_head(); ?>

</head>

<body>

    <header id="main_header" class="main_header">
        <div class="main_header--inner">
            <div class="main_header--wrap">
                <div class="main_header--logo">
                    <img src="logo.png" alt="" srcset="">
                </div> 
                <div class="main_header--nav-ctn">

                    <ul>

                        <li><a href="#">HOME</a></li>
                        <li><a href="#">ABOUT</a></li>
                        <li><a href="#">EXPERTISE</a></li>
                        <li><a href="#">TEAMS</a></li>
                        <li><a href="#">WORKS</a></li>
                        <li><a href="#">PEOPLESAY</a></li>
                        <li><a href="#">CONTACT</a></li>
                    </ul>

                </div>

            </div>
        </div>
    </header>

</body>

</html>