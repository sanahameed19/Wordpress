<style>
  

.main_footer {
    background-color: #000000;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside{
    width: 1440px;
    margin: auto;
    height: 200px;
    text-align: center;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside{
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: 1fr 1fr 1fr;
        grid-template-columns: 1fr 1fr 1fr;
    margin: auto;
    padding-top: 90px;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .left {
    padding-left: 70px;
  }
  
  .main_footer .main_footer--wrapr .footer-wrapper-inside .left img {
    margin-left: -160px;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .left p {
    text-align: left;
    color: white;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .center {
    margin-left: 150px;
    text-align: left;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .center h5 {
    color: white;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .center ul {
    list-style: none;
    padding: 0px;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .center ul li {
    margin-top: 10px;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .center ul li a {
    text-decoration: none;
    color: white;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .right {
    text-align: left;
  }
  
  .main_footer.main_footer--wrap .footer-wrapper-inside .right h5 {
    color: white;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .right p {
    color: white;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .right form input {
    padding-top: 14px;
    padding-bottom: 14px;
    padding-right: 140px;
    padding-left: 20px;
    border: none;
    border-radius: 4px;
  }
  
  .main_footer .main_footer--wrap .footer-wrapper-inside .right form button {
    padding-top: 15px;
    padding-bottom: 15px;
    border: none;
    padding-left: 30px;
    padding-right: 30px;
    margin-top: 15px;
    color: rgb(46, 44, 44);
    background-color: #d3dadb;
    cursor: pointer;
  }
  
  .main_footer .footer-copywrite {
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: 1fr 1fr  ;
        grid-template-columns: 1fr 1fr;
    text-align: left;
    padding-left: 60px;
    margin-top: 120px;
  }
  
  .main_footer .footer-copywrite .copywrite-left p {
    color: white;
    margin-left: 250px;
  }
  
  .main_footer .footer-copywrite .copywrite-right {
    margin-left: 170px;
  }
  
  .main_footer  .footer-copywrite .copywrite-right ul {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    list-style: none;
  }
  
  .main_footer .footer-copywrite .copywrite-right ul li {
    margin-right: 30px;
  }
  
  .main_footer .footer-copywrite .copywrite-right ul li a {
    text-decoration: none;
    color: white;
  }

  .center{
    color: white;
  }
 h5{
   color: white;
 }
.left p{
  padding-left: 40px;
}
</style>

  <footer id="main_footer" class="main_footer">

    <div class="main_footer--wrap">
      <div class="footer-wrapper-inside">
        <div class="left">
          <img src="logo.png" alt="" srcset="" />
          <p>
            It is a long established fact that a reader will be<br /> distracted by the readable content of a page when
            looking at its layout.
          </p>
        </div>
        <div class="center">
          <h5>OUR STUDIO</h5>
          Address: Alhafeez Shopping Mall, Lahore, Pakistan
          <br /><br />
          Phone: +92 301453929299
        </div>

        <div class="right">
          <h5>SIGNUP NEWSLETTER</h5>
          <p>Receive update and discount packages</p>

          <form action="submit" method="get">
            <input type="email" placeholder="Email Address" />

            <button type="submit">SUBSCRIBE</button>

          </form>
          <!-- <a href="#" class="fa fa-facebook"></a>
          <a href="#" class="fa fa-twitter"></a> -->
        </div>

      </div>


      <div class="footer-copywrite">
        <div class="copywrite-left">
          <p>All rights reserved by Ventix Media</p>
        </div>
        <div class="copywrite-right">
          <ul>
            <li><a href="#">HELP</a></li>
            <li><a href="#">PRIVACY</a></li>
            <li><a href="#">TERM AND CONDITIONS</a></li>
          </ul>
        </div>
      </div>
    </div>
    </div>
    </div>
  </footer>

<?php wp_footer(); ?>

</body>
</html>