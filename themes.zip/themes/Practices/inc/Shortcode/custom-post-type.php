<?php

// Example shortcode
// [sample]
function wp_expertise_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'title' => false,
        'limit' => 4,
    ), $atts );

    ob_start(); ?>
   

    <section id="expertise_section" class="expertise_section">
        <div class="expertise_section--inner">
            <div class="heading">
                <h1>EXPERTISE</h1>
                <p>It is a long established fact that a reader will be distracted by the readable content </p>
            </div>
            <div class="expertise_section--wrap">
               
                <?php
                // The Query
                $args = array(
                    "post_type" => "expertise",
                    "post_status" => array("publish", "draft"),
                    "posts_per_page" => -1,
                    "order" => "DESC"
                );
                $the_query = new WP_Query( $args );
                
                // The Loop
                if ( $the_query->have_posts() ) {
                    while ( $the_query->have_posts() ) { $the_query->the_post();
                        ?>

                        <div class="service-box">
                            <?php the_post_thumbnail("full"); ?>
                            <h2 class="title"><?php the_title(); ?></h2>
                            <p class="description"><?php the_content(); ?> </p>
                        </div>

                        <?php
                   }
                } else {
                    // no posts found
                }
                /* Restore original Post Data */
                wp_reset_postdata();
                ?>

                <?php /*
                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">Web Design and Development</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout. </p>
                </div>

                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">Branding Identity</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout. </p>
                </div>

                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">Mobile App</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout. </p>
                </div>
                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">WordPress</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout.</p>
                </div>
                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">SEO</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout. </p>
                </div>

                <div class="service-box">
                <img src="<?php echo get_template_directory_uri(); ?>/img/pc.png" alt="" srcset="" />
                    <h2 class="title">Content Writing</h2>
                    <p class="description">It is a long established fact that a reader will be distracted by the
                        readable content of a page when looking at its layout. </p>
                </div>
                */ ?>
            </div>
        </div>

    </section>

<?php $output = ob_get_contents(); ob_get_clean(); return $output; } add_shortcode( 'wp_expertise', 'wp_expertise_shortcode' );

function wp_expertise_shortcode_css() { ?>
    <style>
        .expertise_section{
        width: 1440px;
        margin: auto;
        }
        .expertise_section--wrap{
        display: -ms-grid;
        display: grid;
        -ms-grid-columns: 1fr 1fr 1fr ;
        grid-template-columns: 1fr 1fr 1fr ;
        column-gap: 50px;
        }

        .expertise_section .heading{
            margin-top: 80px;
            padding-bottom: 80px;
        align-items: center;
        text-align: center;

        }
        .expertise_section .service-box {
        min-height: 200px;
        width: 480px;
        text-align: center;
        }

        .expertise_section .service-box img {
            width: 100px;
        height: auto;
        margin-top: 100px;
        }

        .expertise_section .service-box h2 {
        color: rgb(0, 0, 0);
        }

        .expertise_section .service-box .description {
        color: rgb(0, 0, 0);
        }
    </style>
<?php } add_action('wp_head', 'wp_expertise_shortcode_css' );

  