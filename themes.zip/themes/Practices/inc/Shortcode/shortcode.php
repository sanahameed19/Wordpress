<?php

require "Banner_shortcode.php";
require "custom-post-type.php";



?>
