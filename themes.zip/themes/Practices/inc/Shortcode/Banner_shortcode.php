<?php

// Example shortcode
// [sample]
function wpdocs_Fcode( $atts, $content ) {
    $atts = shortcode_atts( array(
        'title' => 'We are Awasome creative agency',
        'href' => '',
        'btn' => 'Learn More',
    ), $atts );

    ob_start(); ?>

    <main id="main_section" class="main_section">
        <div class="main_section--inner">
            <div class="main_section--wrap">
                <h1><?php echo $atts["title"]; ?></h1>
                <?php echo $content; ?>
                <div>
                <a href="<?php echo $atts["href"]; ?>" class="main_section--btn"><?php echo $atts["btn"]; ?></a>
                </div>
            </div>
        </div>
    </main>

<?php $output = ob_get_contents(); ob_get_clean(); return $output; } add_shortcode( 'wpdocs_the_shortcode', 'wpdocs_Fcode' );

function wpdocs_Fcode_CSS() { ?>
    <style>
        .main_section{
            align-items: center;
            text-align: center;
            background-color: rgb(142, 142, 197);
            color: white;
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .main_section--btn{
            padding: 10px 30px 10px 30px ;
        }
    </style>
<?php } add_action('wp_head', 'wpdocs_Fcode_CSS' );

  