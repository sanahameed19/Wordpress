<?php

// Register a custom menu page.
function media_upload_settings_register(){
    add_menu_page(
		__( 'Media Upload', 'wp' ),
		__( 'Media Upload', 'wp' ),
		'manage_options',
		'media_upload_setting_page',
		'media_upload_setting_page'
	);
} add_action( 'admin_menu', 'media_upload_settings_register' );

// Display a custom menu page
function media_upload_setting_page() { ?><div class="wrap">

    <h2><?php echo __( 'Media Upload URL', 'wp' ); ?></h2>

    <?php if(isset($_POST["submit"])) { // ISSET BTN

        $file = $_POST["media_upload_url"];
        $filename = basename($file);

        $upload_file = wp_upload_bits($filename, null, file_get_contents($file));
        if (!$upload_file['error']) {
            $wp_filetype = wp_check_filetype($filename, null );
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_parent' => $parent_post_id,
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            $attachment_id = wp_insert_attachment( $attachment, $upload_file['file'], $parent_post_id );
            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . "wp-admin" . '/includes/image.php');
                $attachment_data = wp_generate_attachment_metadata( $attachment_id, $upload_file['file'] );
                wp_update_attachment_metadata( $attachment_id,  $attachment_data );
            }
        }

	} // ISSET BTN ?>

    <form action="" method="post">
        <table class="form-table" role="presentation"><tbody>
            <tr>
                <th scope="row"><label for="media_upload_url"><?php echo __('Media Upload URL', 'wp'); ?></label></th>
                <td><input name="media_upload_url" type="text" id="media_upload_url" value="" class="regular-text"></td>
            </tr>
        </tbody></table>
		<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo __('Save Changes', 'wp'); ?>" /></p>
    </form>

</div><?php }